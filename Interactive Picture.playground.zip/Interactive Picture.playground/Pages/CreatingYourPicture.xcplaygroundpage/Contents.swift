//: [Previous](@previous)
import SwiftUI
import PlaygroundSupport


/*:
 # Creating Your Animated Picture 🎉
 ---
### Aren't you tired of old pictures now?🖼
 ---
 We are now in the Technology Age and our possibilities are wider. You can create your own shape by running this project and add an animation to it to make it a moving picture. 👨‍🎨
 
 */

/*: Each shape has its own animation.And with your creativity, you can create great pictures. Have fun.😉
 
---
 ### IMPORTANT
 Each shape can be used only once.
 */
struct CreateShape : View{
    @State private var rect0: CGRect = .zero
    @State private var uiimage: UIImage? = nil
    @State private var currentDrawing: Drawing = Drawing()
    @State private var drawings: [Drawing] = [Drawing]()
    @State private var color: Color = .red
    @State private var lineWidth: CGFloat = 3.0
    @State var isSave : Bool = false

    var body: some View{
        ZStack{
            VStack{
                
            HStack{
                VStack{
                        DrawingPad(currentDrawing: $currentDrawing, drawings: $drawings, color: $color, lineWidth: $lineWidth)
                            .frame(width: 200, height: 200)
                            .cornerRadius(1)
                            .background(RectGetter(rect: $rect0))
                            .onTapGesture { self.uiimage = UIApplication.shared.windows[0].rootViewController?.view.asImage(rect: self.rect0) }
                            
                    
                   
                    HStack{
                        Button(action: {
                            self.drawings.removeAll()
                        }){
                            Text("Clear").bold()
                        }.frame(width: 120, height: 40)
                            .foregroundColor(Color.white)
                            .background(color)
                            .cornerRadius(10)
                        Button(action: {
                            self.uiimage =  UIApplication.shared.windows[0].rootViewController?.view.asImage(rect: self.rect0)
                            
                            withAnimation{self.isSave.toggle()}
                        }){
                            Text("Save").bold()
                        }.frame(width: 120, height: 40)
                        .foregroundColor(Color.white)
                        .background(Color.red)
                        .cornerRadius(10)
                             
                    }
                }.padding()
                
                ColorPicker(chosenColor: $color)
                    .frame(width: 50, height: 200)
            
                VStack{
                    Text("Drawing Pad")
                        .bold()
                        .font(.system(size: 30))
                        .foregroundColor(Color.black)
                    Text("The shape we draw on the drawing pad will be in the middle of the picture we will create.If you want, you can save it without doing anything.\n Example (Apple Logo,Emoji,a Letter) ")
                        .padding()
                }.padding()
            }
     
        }
            if isSave{
                ZStack{
                    Spacer()
                    AnimationView(image: uiimage)
                }.edgesIgnoringSafeArea(.all).offset(x: 0, y: self.isSave ? 0 : 653 )
            }
        }
      
       
    }
}

//:We create a drawing pad and record every line drawn.
struct Drawing {
    var points: [CGPoint] = [CGPoint]()
}


struct DrawingPad: View {
    @Binding var currentDrawing: Drawing
    @Binding var drawings: [Drawing]
    @Binding var color: Color
    @Binding var lineWidth: CGFloat
    
    var body: some View {
        GeometryReader { geometry in
            Path { path in
                for drawing in self.drawings {
                    self.add(drawing: drawing, toPath: &path)
                }
                self.add(drawing: self.currentDrawing, toPath: &path)
            }
            .stroke(self.color, lineWidth: self.lineWidth)
            .background(Color.black)
            .gesture(
                DragGesture(minimumDistance: 0.1)
                    .onChanged({ (value) in
                        let currentPoint = value.location
                        if currentPoint.y >= 0
                            && currentPoint.y < geometry.size.height {
                            self.currentDrawing.points.append(currentPoint)
                        }
                    })
                    .onEnded({ (value) in
                        self.drawings.append(self.currentDrawing)
                        self.currentDrawing = Drawing()
                    })
            )
        }
        .frame(maxHeight: .infinity)
    }
    
    private func add(drawing: Drawing, toPath path: inout Path) {
        let points = drawing.points
        if points.count > 1 {
            for i in 0..<points.count-1 {
                let current = points[i]
                let next = points[i+1]
                path.move(to: current)
                path.addLine(to: next)
            }
        }
    }
    
}



//:The purpose of using RectGetter structure and extension is to convert the image from Drawing Pad to Image.
extension UIView {
    func asImage(rect: CGRect) -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: rect)
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }
}


struct RectGetter: View {
    @Binding var rect: CGRect

    var body: some View {
        GeometryReader { proxy in
            self.createView(proxy: proxy)
        }
    }

    func createView(proxy: GeometryProxy) -> some View {
        DispatchQueue.main.async {
            self.rect = proxy.frame(in: .global)
        }

        return Rectangle().fill(Color.clear)
    }
}


//:While creating this color picker, I was injured by the text of Brandon Baars, and I created a simple color picker.([Medium](https://levelup.gitconnected.com/swiftui-create-a-custom-gradient-color-picker-like-snapchats-bcf508e69380))
struct ColorPicker: View {
    @Binding var chosenColor: Color
    
    // 1
    @State private var isDragging: Bool = false
    @State private var startLocation: CGFloat = .zero
    @State private var dragOffset: CGSize = .zero
    
    init(chosenColor: Binding<Color>) {
        self._chosenColor = chosenColor
    }
    
    private var colors: [Color] = {
        let hueValues = Array(0...359)
        return hueValues.map {
            Color(UIColor(hue: CGFloat($0) / 359.0 ,
                          saturation: 1.0,
                          brightness: 1.0,
                          alpha: 1.0))
        }
    }()
    
    // 2
    private var circleWidth: CGFloat {
        isDragging ? 35 : 15
    }
    
    private var linearGradientHeight: CGFloat = 200
    

    private var currentColor: Color {
        Color(UIColor.init(hue: self.normalizeGesture() / linearGradientHeight, saturation: 1.0, brightness: 1.0, alpha: 1.0))
    }
    
 
    
    private func normalizeGesture() -> CGFloat {
        let offset = startLocation + dragOffset.height
        
        let maxY = max(0, offset)
        
        let minY = min(maxY, linearGradientHeight)
        
        return minY
    }
    
    var body: some View {
        // 3
        ZStack(alignment: .top) {
            LinearGradient(gradient: Gradient(colors: colors),
                           startPoint: .top,
                           endPoint: .bottom)
                .frame(width: 10, height: linearGradientHeight)
                .cornerRadius(5)
                .shadow(radius: 8)
                .overlay(
                        RoundedRectangle(cornerRadius: 5).stroke(Color.white, lineWidth: 2.0)
                )
                .gesture(
                    DragGesture()
                        .onChanged({ (value) in
                            self.dragOffset = value.translation
                            self.startLocation = value.startLocation.y
                            self.chosenColor = self.currentColor
                            self.isDragging = true // 4
                        })
                        // 5
                        .onEnded({ (_) in
                            self.isDragging = false
                        })
            )
            
            // 6
            Circle()
                .foregroundColor(self.currentColor)
                .frame(width: self.circleWidth, height: self.circleWidth, alignment: .center)
                .shadow(radius: 5)
                .overlay(
                    RoundedRectangle(cornerRadius: self.circleWidth / 2.0).stroke(Color.white, lineWidth: 2.0)
                )
                .offset(x: self.isDragging ? -self.circleWidth : 0.0, y: self.normalizeGesture() - self.circleWidth / 2)
                .animation(Animation.spring().speed(2))
        }
    }
}

 
//:We create the view  where we will create your Picture.


struct AnimationView : View {
    @State private var sunLightPosition : CGPoint = .zero
    @State private var sunLightSelected : Bool = false
    
    @State private var gearPosition : CGPoint = .zero
    @State private var gearSelected : Bool = false
    
    @State private var daisyPosition : CGPoint = .zero
    @State private var daisySelected : Bool = false
    
    @State private var spiningBallPosition : CGPoint = .zero
    @State private var spiningBallSelected : Bool = false
    
    @State private var squareSpinnerPosition : CGPoint = .zero
    @State private var squareSpinnerSelected : Bool = false
    
    @State private var breathPosition : CGPoint = .zero
    @State private var breathSelected : Bool = false
    
    @State private var spiographPosition : CGPoint = .zero
    @State private var spiographSelected : Bool = false
    
    @State private var paintPosition : CGPoint = .zero
    @State private var paintSelected : Bool = false
    
    @State private var crabPosition : CGPoint = .zero
    @State private var crabSelected : Bool = false
    
    @State private var frameSelected : Bool = false
    
    @State var image : UIImage?
    @State  private var selected = 0
    @State private var color : Color = .black
    
    var body: some View{
        ZStack{
            Color.black
            Image(uiImage: self.image!)
                .offset(x: 0, y: -60)
            if self.frameSelected == true {
                Frame()
                    .position(CGPoint(x: 240, y: 110))
                    .frame(width: 478  , height: 357)
            }
            Group{
                if self.sunLightSelected == true {
                    SunLight(color: Color.white).position(sunLightPosition)
                }
                if self.gearSelected == true {
                    Gear(color: Color.white).position(gearPosition)
                }
                if self.daisySelected == true {
                    Daisy().position(daisyPosition)
                }
                if self.spiningBallSelected == true {
                    SpiningBall().position(spiningBallPosition)
                }
                if self.squareSpinnerSelected == true {
                    SquareSpinner().position(squareSpinnerPosition)
                }
                if self.breathSelected == true {
                    Breath().position(breathPosition)
                }
                if self.spiographSelected == true {
                    Spiograph()
                        .position(spiographPosition).offset(x: -280, y: -210)
                        .frame(width: 90, height: 90)
                }
                if self.paintSelected == true {
                    Paint()
                        .position(paintPosition).offset(x: -160, y: -200)
                        .frame(width: 400, height: 400)
                }
                if self.crabSelected == true {
                    Crab()
                        .position(crabPosition).offset(x: -160, y: -100)
                        .frame(width: 400, height: 400)
                }
            }
            Background{location in
                switch self.selected {
                case 10:
                    self.sunLightPosition = CGPoint(x: location.x, y: location.y)
                    self.sunLightSelected = true
                case 9:
                    self.gearPosition = CGPoint(x: location.x, y: location.y)
                    self.gearSelected = true
                case 8:
                    self.spiningBallPosition = CGPoint(x: location.x, y: location.y)
                    self.spiningBallSelected = true
                case 7:
                    self.daisyPosition = CGPoint(x: location.x, y: location.y)
                    self.daisySelected = true
                case 6:
                    self.squareSpinnerPosition = CGPoint(x: location.x, y: location.y)
                    self.squareSpinnerSelected = true
                case 5:
                    self.breathPosition = CGPoint(x: location.x, y: location.y)
                    self.breathSelected = true
                case 4:
                    self.spiographPosition = CGPoint(x: location.x, y: location.y)
                    self.spiographSelected = true
                case 3:
                    self.frameSelected = true
                case 2:
                    self.paintPosition = CGPoint(x: location.x, y: location.y)
                    self.paintSelected = true
                case 1:
                    self.crabPosition = CGPoint(x: location.x, y: location.y)
                    self.crabSelected = true
                default:
                    break
                }
            }
            
           

          
            VStack{
                Spacer()
                ZStack{
                    
                    Rectangle().fill(Color.white).frame(width: 653, height: 112)
                    
                    ScrollView(.horizontal, showsIndicators: false){
                        HStack{
                            
                            ForEach(1...10, id: \.self){ number in
                                ZStack{
                                    Rectangle()
                                        .fill(Color.white)
                                        .frame(width: 75, height: 70)
                                        .shadow(radius: 5)
                                    Button (action: {
                                        self.selected = number
                                    }){
                                        if number == 10{
                                            SunLight(color: Color.black)
                                        }; if number == 9{
                                            Gear(color: Color.black)
                                        }; if number == 8{
                                            SpiningBall().shadow(radius: 10)
                                        };if number == 7{
                                            Daisy()
                                        };if number == 6{
                                            SquareSpinner()
                                        };if number == 5{
                                            Breath()
                                        };if number == 4{
                                            Spiograph().frame(width: 65, height: 65)
                                        };if number == 3{
                                            Frame().frame(width: 65, height: 65)
                                        };if number == 2{
                                            Paint().frame(width: 65, height: 65)
                                        };if number == 1{
                                            Crab().frame(width: 65, height: 65)
                                        }
                                    }
                                    .padding()
                                }
                                
                            }
                            
                            
                        }
                    }
                }
            }
            Image(uiImage: UIImage(named: "retry")!)
                .resizable()
                .scaledToFit()
                .frame(width: 25, height: 25).position(x: 600, y: 40)
                .gesture(TapGesture().onEnded({ (_) in
                                self.sunLightSelected = false
                                self.gearSelected = false
                                self.spiningBallSelected = false
                                self.daisySelected = false
                                self.squareSpinnerSelected = false
                                self.breathSelected = false
                                self.spiographSelected = false
                                self.frameSelected = false
                                self.paintSelected = false
                    self.crabSelected = false
                    self.crabPosition = .zero
                    self.sunLightPosition = .zero
                    self.gearPosition = .zero
                    self.spiningBallPosition = .zero
                    self.daisyPosition = .zero
                    self.squareSpinnerPosition = .zero
                    self.breathPosition = .zero
                    self.spiographPosition = .zero
                    self.paintPosition = .zero


                }))
        }
    }
}

//:We create all of our shapes in a structure.
struct Spiograph : View{
    var body: some View {
        Image(uiImage: UIImage(named: "Spiograph")!)
            .resizable()
            .scaledToFit()
    }
    
}
struct Frame : View{
    var body: some View {
        Image(uiImage: UIImage(named: "frame2")!)
            .resizable()
            .scaledToFit()
    }
    
}

struct Paint : View{
    var body: some View {
        Image(uiImage: UIImage(named: "paint")!)
            .resizable()
            .scaledToFit()
    }
    
}

struct Crab : View{
    var body: some View {
        Image(uiImage: UIImage(named: "crab")!)
            .resizable()
            .scaledToFit()
    }
    
}

struct Breath: View {
    @State private var breath = false
    @State private var showCentralCircle = false
    var body: some View {
        ZStack {
            ZStack {
                ZStack { // Vertical
                    ZStack { // Square gradient
                        RadialGradient(gradient: Gradient(colors: [Color.green, Color.yellow]), center: .center, startRadius: 5, endRadius: 100)
                            .clipShape(Circle()).frame(width: 65, height: 65) // Clip gradient to circle
                            .offset(y: -41)
                    }
                    
                    ZStack {
                        RadialGradient(gradient: Gradient(colors: [Color.green, Color.yellow]), center: .center, startRadius: 5, endRadius: 90)
                            .clipShape(Circle()).frame(width: 65, height: 65)
                            .offset(y: 41)
                    }
                }.opacity(0.5)
                
            ZStack { // At 60°
                ZStack {
                    RadialGradient(gradient: Gradient(colors: [Color.green, Color.yellow]), center: .center, startRadius: 5, endRadius: 100)
                        .clipShape(Circle()).frame(width: 65, height: 65)
                        .offset(y: -41)
                }
                
                ZStack {
                    RadialGradient(gradient: Gradient(colors: [Color.green, Color.yellow]), center: .center, startRadius: 5, endRadius: 90)
                        .clipShape(Circle()).frame(width: 65, height: 65)
                        .offset(y: 41)
                }
            }.opacity(0.5).rotationEffect(.degrees(60), anchor: .center)
                
            ZStack { // At 60*2°
                ZStack {
                    RadialGradient(gradient: Gradient(colors: [Color.green, Color.yellow]), center: .center, startRadius: 5, endRadius: 100)
                        .clipShape(Circle()).frame(width: 65, height: 65)
                        .offset(y: -41)
                }
                
                ZStack {
                    RadialGradient(gradient: Gradient(colors: [Color.green, Color.yellow]), center: .center, startRadius: 5, endRadius: 90)
                        .clipShape(Circle()).frame(width: 65, height: 65)
                        .offset(y: 41)
                }
            }.opacity(0.5).rotationEffect(.degrees(60*2), anchor: .center)
                
            }// Whole flower
            .rotationEffect(.degrees(breath ? 360 : 0), anchor: .center) // Inhale = clockwise rotation, Exhale = anticlockwise rotation
                .scaleEffect(breath ? 0.6 : 0.2) // Inhale = upscale, Exhale = downscale
            .animation(Animation.easeInOut(duration: 4).delay(1).repeatForever(autoreverses: true))
                .opacity(breath ? 0.8 : 0.5)
            .onAppear() {
                    self.breath.toggle()
            }
            
            Circle() // Central Circle
                .frame(width: 33, height: 33)
                .foregroundColor(.green)
                .scaleEffect(showCentralCircle ? 0 : 0.8)
                .opacity(showCentralCircle ? 0 : 1)
                .blendMode(.plusLighter)
            .blur(radius: 1)
                .animation(Animation.easeInOut(duration: 4).delay(1).repeatForever(autoreverses: true))
                .onAppear() {
                    self.showCentralCircle.toggle()
            }

        }
    }
}
struct SquareSpinner: View {
    @State private var animateBottomRight = false
    @State private var animateTopLeft = false
    @State private var animateTopRight = false
    @State private var animateBottomLeft = false
    var body: some View {
        ZStack {
            Rectangle() // Middle
                .frame(width:20, height: 20)
            
            Rectangle()  // Bottom right
                .frame(width:30, height: 30)
                .scaleEffect(animateBottomRight ? 1 : 0.2)
                .offset(x: animateBottomRight ? 20 : 0, y: animateBottomRight ? 20 : 0)
                .animation(Animation.easeInOut.repeatForever(autoreverses: true).speed(0.8))
                .onAppear() {
                    self.animateBottomRight.toggle()
            }
            
            Rectangle() // Top left
                .frame(width:30, height: 30)
                .scaleEffect(animateTopLeft ? 1 : 0.2)
                .offset(x: animateTopLeft ? -20 : 0, y: animateTopLeft ? -20 : 0)
                .animation(Animation.easeInOut.repeatForever(autoreverses: true).speed(0.8))
                    .onAppear() {
                        self.animateTopLeft.toggle()
                }
            
            Rectangle() // Top right
                .frame(width: 20, height: 20)
                .scaleEffect(animateTopRight ? 0.2 : 1.5)
                .offset(x: animateTopLeft ? 0 : 20, y: animateTopRight ? 0 : -20)
            .animation(Animation.easeInOut.repeatForever(autoreverses: true).speed(0.8))
                .onAppear() {
                        self.animateTopRight.toggle()
                }
            
            Rectangle() // Bottom left
                .frame(width: 20, height: 20)
                .scaleEffect(animateBottomLeft ? 0.2 : 1.5)
                    .offset(x: animateBottomLeft ? 0 : -20, y: animateBottomLeft ? 0 : 20)
                .animation(Animation.easeInOut.repeatForever(autoreverses: true).speed(0.8))
                    .onAppear() {
                            self.animateBottomLeft.toggle()
                    }
        }.foregroundColor(.pink
        )
        
    }
}


struct SpiningBall : View {
    @State private var scaleAll = false
    @State private var rotateOuter = false
    var body: some View {
        ZStack {
            ZStack {
                
                Circle()
                    .frame(width: 32.5, height: 32.5)
                .foregroundColor(.white)
                ZStack {
                    Circle()  //
                        .trim(from: 1/2, to: 4/5)
                        .stroke(style: .init(lineWidth: 3, lineCap: .round, lineJoin: .round))
                        .frame(width: 65, height: 65)
                        .foregroundColor(.white)
                    Circle()  //
                        .trim(from: 1/2, to: 4/5)
                        .stroke(style: .init(lineWidth: 3, lineCap: .round, lineJoin: .round))
                        .frame(width: 65, height: 65)
                        .foregroundColor(.blue)
                        .rotationEffect(.degrees(180))
                    
                }
                .rotationEffect(.degrees(rotateOuter ? 360*3 : 0))
                .animation(Animation.spring(response: 0.87, dampingFraction: 0.1, blendDuration: 0.3).repeatForever(autoreverses: true))
                .onAppear() {
                    self.rotateOuter.toggle()
                }
            }.scaleEffect(scaleAll ? 1 : 0.3)
            .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true))
            .onAppear() {
                self.scaleAll.toggle()
            }
        }
    }
}

struct SunLight : View{
    var color  : Color
    var body:some View{
        Circle()
            .strokeBorder(style: StrokeStyle(lineWidth: 45, lineCap: .butt, lineJoin: .round, dash: [7,3], dashPhase: 0))
            .foregroundColor(color)
            .opacity(1)
            .frame(width: 65 , height: 65)
              
          
           
      }
}

struct Daisy : View{
    @State private var animateSmaller = false
    @State private var animateMedium = false
    @State private var animateLarger = false
    var body: some View{
        ZStack{
            
            // Circle: Larger
            Circle()
                .frame(width: 65+20, height: 65+20)
                .foregroundColor(Color(#colorLiteral(red: 0.4620226622, green: 0.8382837176, blue: 1, alpha: 1)))
                .opacity(0.5)
            .scaleEffect(animateLarger ? 1.2 : 0.5, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.3))
                .onAppear() {
                    self.animateLarger.toggle()
            }
            
            // Circle: Medium
            Circle()
                .frame(width: 45+10, height: 45+10)
                .foregroundColor(Color(#colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)))
                .opacity(0.5)
                .scaleEffect(animateMedium ? 1.2 : 0.5, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.2))
                .onAppear() {
                    self.animateMedium.toggle()
            }
            
            
            // Circle: Smaller
            Circle()
                .frame(width: 45, height: 45)
                .foregroundColor(Color(#colorLiteral(red: 0, green: 0.3285208941, blue: 0.5748849511, alpha: 1)))
                .opacity(0.5)
                .scaleEffect(animateSmaller ? 1.2 : 0.5, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.1))
                .onAppear() {
                    self.animateSmaller.toggle()
            }

        }
    }
    
}

struct Gear : View{
    var color  : Color
    var body:some View{
        Circle()
            .strokeBorder(style: StrokeStyle(lineWidth: 30, lineCap: .square, lineJoin: .miter, miterLimit : 1, dash: [9,10], dashPhase: 1))
            .foregroundColor(color)
            .opacity(1)
            .frame(width: 65 , height: 65)
              
          
           
      }
}

struct CuttingLine : View{
    var color  : Color
    var body:some View{
        Circle()
            .strokeBorder(style: StrokeStyle(lineWidth: 15, lineCap: .butt, lineJoin: .round, dash: [1,7], dashPhase: 2.5))
            .foregroundColor(color)
            .opacity(1)
            .frame(width: 65 , height: 65)
      }
}



//:And when we click on the screen, we use the Background structure to get the location of the clicked place.

    
struct Background:UIViewRepresentable {
    var tappedCallback: ((CGPoint) -> Void)

    func makeUIView(context: UIViewRepresentableContext<Background>) -> UIView {
        let vie = UIView(frame: .zero)
        let gesture = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tapped))
        vie.addGestureRecognizer(gesture)
        return vie
    }

    class Coordinator: NSObject {
        var tappedCallback: ((CGPoint) -> Void)
        init(tappedCallback: @escaping ((CGPoint) -> Void)) {
            self.tappedCallback = tappedCallback
        }
        @objc func tapped(gesture:UITapGestureRecognizer) {
            let point = gesture.location(in: gesture.view)
            self.tappedCallback(point)
        }
    }

    func makeCoordinator() -> Background.Coordinator {
        return Coordinator(tappedCallback:self.tappedCallback)
    }

    func updateUIView(_ uiView: UIView,
                       context: UIViewRepresentableContext<Background>) {
    }

}

var view = UIHostingController(rootView: CreateShape())
view.preferredContentSize = CGSize(width: 653, height: 527)
PlaygroundPage.current.liveView = view



